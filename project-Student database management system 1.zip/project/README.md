# Student Management System

A modern web application for managing student records with a clean, responsive interface built using React, TypeScript, and Tailwind CSS.

## Features

- **Complete CRUD Operations**
  - Create new student records
  - View student details
  - Update existing student information
  - Delete student records

- **Advanced Search**
  - Search students by name or ID
  - Real-time search results

- **Student Information**
  - Student ID
  - Name
  - Age
  - Gender
  - Mobile Number
  - Address
  - Major
  - Course
  - Branch
  - GPA
  - Attendance

- **Modern UI/UX**
  - Responsive design
  - Clean and intuitive interface
  - Smooth transitions
  - Form validation
  - Confirmation dialogs

## Technology Stack

- **Frontend**
  - React 18
  - TypeScript
  - Tailwind CSS
  - React Router DOM
  - Lucide React (icons)

- **Database**
  - Dexie.js (IndexedDB wrapper)
  - Browser's IndexedDB for persistent storage

## Getting Started

1. **Installation**
   ```bash
   npm install
   ```

2. **Development**
   ```bash
   npm run dev
   ```

3. **Build**
   ```bash
   npm run build
   ```

## Project Structure

```
src/
├── components/         # React components
│   ├── Layout.tsx     # Main layout component
│   ├── StudentList.tsx    # Student list view
│   ├── StudentForm.tsx    # Reusable form component
│   ├── AddStudent.tsx     # Add student view
│   ├── EditStudent.tsx    # Edit student view
│   └── ViewStudent.tsx    # Student details view
├── db.ts              # Database configuration
├── utils/
│   └── sampleData.ts  # Sample data for initialization
├── App.tsx            # Main application component
└── main.tsx          # Application entry point
```

## Features in Detail

### Student Management
- Add new students with comprehensive information
- View detailed student profiles
- Edit existing student records
- Delete student records with confirmation
- Search functionality for quick access to student records

### Data Persistence
- All data is stored locally using IndexedDB
- Automatic data initialization with sample records
- Real-time updates using Dexie.js live queries

### User Interface
- Responsive design that works on all devices
- Clean and intuitive navigation
- Form validation for data integrity
- Confirmation dialogs for destructive actions
- Search functionality with real-time results

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.