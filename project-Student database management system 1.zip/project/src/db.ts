import Dexie, { Table } from 'dexie';

export interface Student {
  id?: number;
  studentId: string;
  name: string;
  age: number;
  gender: string;
  mobile: string;
  address: string;
  major: string;
  course: string;
  branch: string;
  gpa: number;
  attendance: number;
}

export class StudentDatabase extends Dexie {
  students!: Table<Student>;

  constructor() {
    super('StudentDB');
    this.version(1).stores({
      students: '++id, studentId, name'
    });
  }
}

export const db = new StudentDatabase();