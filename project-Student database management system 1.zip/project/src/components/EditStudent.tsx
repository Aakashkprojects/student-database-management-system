import { useNavigate, useParams } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import { StudentForm } from './StudentForm';
import type { Student } from '../db';

export function EditStudent() {
  const { id } = useParams();
  const navigate = useNavigate();
  const student = useLiveQuery(
    () => db.students.get(Number(id)),
    [id]
  );

  const handleSubmit = async (data: Omit<Student, 'id'>) => {
    if (id) {
      await db.students.update(Number(id), data);
      navigate('/');
    }
  };

  if (!student) return <div>Loading...</div>;

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-6">Edit Student</h2>
        <StudentForm student={student} onSubmit={handleSubmit} submitLabel="Save Changes" />
      </div>
    </div>
  );
}