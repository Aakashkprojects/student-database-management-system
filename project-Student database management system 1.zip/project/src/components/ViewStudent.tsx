import { useParams, Link } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';

export function ViewStudent() {
  const { id } = useParams();
  const student = useLiveQuery(
    () => db.students.get(Number(id)),
    [id]
  );

  if (!student) return <div>Loading...</div>;

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-6">Student Details</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <h3 className="text-sm font-medium text-gray-500">Student ID</h3>
            <p className="mt-1 text-sm text-gray-900">{student.studentId}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Name</h3>
            <p className="mt-1 text-sm text-gray-900">{student.name}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Age</h3>
            <p className="mt-1 text-sm text-gray-900">{student.age}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Gender</h3>
            <p className="mt-1 text-sm text-gray-900">{student.gender}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Mobile</h3>
            <p className="mt-1 text-sm text-gray-900">{student.mobile}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Address</h3>
            <p className="mt-1 text-sm text-gray-900">{student.address}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Major</h3>
            <p className="mt-1 text-sm text-gray-900">{student.major}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Course</h3>
            <p className="mt-1 text-sm text-gray-900">{student.course}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Branch</h3>
            <p className="mt-1 text-sm text-gray-900">{student.branch}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">GPA</h3>
            <p className="mt-1 text-sm text-gray-900">{student.gpa}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Attendance</h3>
            <p className="mt-1 text-sm text-gray-900">{student.attendance}%</p>
          </div>
        </div>
        <div className="mt-6 flex justify-end space-x-4">
          <Link
            to={`/edit/${student.id}`}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            Edit
          </Link>
          <Link
            to="/"
            className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            Back to List
          </Link>
        </div>
      </div>
    </div>
  );
}