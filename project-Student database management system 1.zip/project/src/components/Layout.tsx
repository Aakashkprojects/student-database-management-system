import { Outlet } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';

export function Layout() {
  return (
    <div className="min-h-screen bg-gray-100">
      <div 
        className="bg-cover bg-center h-64 relative" 
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=2000&h=600")',
        }}
      >
        <div className="absolute inset-0 bg-blue-900/75">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
            <div className="flex items-center space-x-4">
              <GraduationCap className="h-12 w-12 text-white" />
              <h1 className="text-3xl font-bold text-white">
                Student Management System
              </h1>
            </div>
            <p className="mt-2 text-blue-100 max-w-xl">
              Efficiently manage student records with our comprehensive system. Track academic progress, 
              attendance, and personal information all in one place.
            </p>
          </div>
        </div>
      </div>

      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">
                SMS Dashboard
              </span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <Outlet />
      </main>

      <footer className="bg-white border-t mt-auto">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500 text-sm">
            © {new Date().getFullYear()} Student Management System. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}