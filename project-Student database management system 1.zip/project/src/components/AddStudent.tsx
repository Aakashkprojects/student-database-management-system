import { useNavigate } from 'react-router-dom';
import { db } from '../db';
import { StudentForm } from './StudentForm';
import type { Student } from '../db';

export function AddStudent() {
  const navigate = useNavigate();

  const handleSubmit = async (data: Omit<Student, 'id'>) => {
    await db.students.add(data);
    navigate('/');
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-6">Add New Student</h2>
        <StudentForm onSubmit={handleSubmit} submitLabel="Add Student" />
      </div>
    </div>
  );
}