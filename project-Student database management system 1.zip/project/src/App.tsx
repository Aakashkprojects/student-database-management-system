import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { StudentList } from './components/StudentList';
import { AddStudent } from './components/AddStudent';
import { EditStudent } from './components/EditStudent';
import { ViewStudent } from './components/ViewStudent';
import { Layout } from './components/Layout';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<StudentList />} />
          <Route path="add" element={<AddStudent />} />
          <Route path="edit/:id" element={<EditStudent />} />
          <Route path="view/:id" element={<ViewStudent />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;